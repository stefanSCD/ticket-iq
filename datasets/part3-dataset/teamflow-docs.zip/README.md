# TeamFlow documentation

Source corpus v1.0. Each of the 100 logical sections represents one corpus page. Use the Markdown file for retrieval and passage IDs (e.g. BR-03-R06); use the PDF and DOCX as readable variants. See `knowledge-registry.md` located beside this ZIP for an index.
